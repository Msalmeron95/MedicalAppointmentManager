using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using Spectre.Console;


namespace MedicalManagementSystem
{
    public class Usuarios
    {
            public int ID { get; set; }
            public string Nombre { get; set; }
            public string Apellido { get; set; }
            public string Email { get; set; }
            public string Contraseña { get; set; }

            public Usuarios()
            {

            }
            public Usuarios(int aID, string aNombre, string aApellido, string aEmail, string aContraseña)
            {
                ID = aID;
                Nombre = aNombre;
                Apellido = aApellido;
                Email = aEmail;
                Contraseña = aContraseña;

            }


            public class Administradores :Usuarios
            {


                public Administradores()
                {

                }
                public Administradores(int aID, string aNombre, string aApellido, string aEmail, string aContraseña):base(aID, aNombre, aApellido, aEmail, aContraseña)
                {

                }

                public static List<Administradores> admins = new List<Administradores>()
                {
                    new Administradores(1, "Martin", "Salmeron", "Msalmeron@gmail.com", "P@$w0rd")
                };


                public static void ManageDoctorPayments()
                {
                    var exitOption = new[] { "Salir" };
                    var doctorOptions = Doctores.doctores.Select(doctor =>
                    {
                        string paymentStatus = doctor.Pago <= 0 ? "[bold red]No paid[/]" : "[bold green]Paid[/]";
                        return $"{doctor.ID}. {doctor.Nombre} {doctor.Apellido} - {doctor.Especialidad} - ${doctor.Pago} - {paymentStatus}";
                    }).Concat(exitOption).ToArray();

                    AnsiConsole.MarkupLine("[bold cyan]Lista de Doctores:[/]");
                    var doctorID = AnsiConsole.Prompt(new SelectionPrompt<string>()
                        .Title("Seleccione un doctor para gestionar su pago")
                        .PageSize(10)
                        .AddChoices(doctorOptions));

                    if (doctorID == "Salir")
                    {
                        Menus.AdministradorsMenu();
                        return;
                    }

                    var selectedDoctorID = int.Parse(doctorID.Split('.')[0]);

                    var doctorToPay = Doctores.doctores.FirstOrDefault(d => d.ID == selectedDoctorID);

                    if (doctorToPay != null)
                    {
                        var paymentAmount = AnsiConsole.Prompt(new TextPrompt<double>("Ingrese el monto del pago:$"));

                        doctorToPay.Pago += paymentAmount;

                        string paymentStatusMarkup = doctorToPay.Pago <= 0 ? "[bold red]No paid[/]" : "[bold green]Paid[/]";

                        AnsiConsole.MarkupLine($"\nPago de ${doctorToPay.Pago} fue realizado exitosamente al Dr. {doctorToPay.Nombre} {doctorToPay.Apellido}. {paymentStatusMarkup}\n");
                        Menus.AdministradorsMenu();
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold red]Doctor no encontrado. Verifique el ID e inténtelo de nuevo.[/]");
                        Menus.AdministradorsMenu();
                    }
                }

                public static void ManageDoctors()
                {
                    var option = AnsiConsole.Prompt(new SelectionPrompt<string>()
                        .Title("Seleccione una opción:")
                        .PageSize(5)
                        .AddChoices("Ver doctores", "Agregar doctor", "Actualizar Doctor", "Eliminar doctor", "Cancelar"));

                    switch (option)
                    {
                        case "Ver doctores":
                            AnsiConsole.Clear();
                            DisplayDoctorsList();
                            AnsiConsole.WriteLine("");
                            ManageDoctors();
                            break;
                        case "Agregar doctor":
                            AnsiConsole.Clear();
                            AddNewDoctor();
                            AnsiConsole.WriteLine("");
                            ManageDoctors();
                            break;
                        case "Actualizar Doctor":
                            AnsiConsole.Clear();
                            UpdateDoctorAttributes(SelectDoctor());
                            AnsiConsole.WriteLine("");
                            ManageDoctors();
                            break;
                        case "Eliminar doctor":
                            AnsiConsole.Clear();
                            DeleteDoctor(SelectDoctor().ID);
                            AnsiConsole.WriteLine("");
                            ManageDoctors();
                            break;
                        case "Cancelar":
                            AnsiConsole.Clear();
                            Menus.AdministradorsMenu();
                            break;
                    }
                }

                private static void DisplayDoctorsList()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Doctores:[/]");
                    foreach (var doctor in Doctores.doctores)
                    {
                        AnsiConsole.MarkupLine($"[yellow]{doctor.ID}.[/] [green]{doctor.Nombre} {doctor.Apellido}[/] - [blue]{doctor.Especialidad}[/]");
                    }
                }

                private static void AddNewDoctor()
                {
                    var newDoctor = new Doctores();

                    newDoctor.Nombre = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese el nombre del nuevo doctor:"));
                    newDoctor.Apellido = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese el apellido del nuevo doctor:"));
                    newDoctor.Email = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese el email del nuevo doctor:"));
                    newDoctor.Contraseña = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese la contraseña del nuevo doctor:"));
                    newDoctor.Pago = AnsiConsole.Prompt(new TextPrompt<double>("Ingrese el pago del nuevo doctor:$"));
                    newDoctor.Especialidad = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese la especialidad del nuevo doctor:"));

                    if (Doctores.doctores.Any(d => d.Nombre == newDoctor.Nombre || d.Email == newDoctor.Email))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: Ya existe un doctor con el mismo nombre o email.[/]");
                        return;
                    }

                    var newDoctorID = Doctores.doctores.Count + 1;
                    newDoctor.ID = newDoctorID;

                    Doctores.doctores.Add(newDoctor);

                    AnsiConsole.MarkupLine($"Nuevo doctor agregado con éxito con ID: {newDoctorID}");
                    DisplayDoctorsList();
                }

                private static void UpdateDoctorAttributes(Doctores doctor)
                {
                    var updateOption = AnsiConsole.Prompt(new SelectionPrompt<string>()
                        .Title($"Seleccione el atributo a actualizar del Dr. {doctor.Nombre} {doctor.Apellido}")
                        .PageSize(5)
                        .AddChoices("Nombre", "Apellido", "Email", "Contraseña", "Pago", "Especialidad", "Cancelar"));

                    switch (updateOption)
                    {
                        case "Nombre":
                            doctor.Nombre = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese el nuevo nombre:"));
                            break;
                        case "Apellido":
                            doctor.Apellido = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese el nuevo apellido:"));
                            break;
                        case "Email":
                            doctor.Email = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese el nuevo email:"));
                            break;
                        case "Contraseña":
                            doctor.Contraseña = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese la nueva contraseña:"));
                            break;
                        case "Pago":
                            doctor.Pago = AnsiConsole.Prompt(new TextPrompt<double>("Ingrese el nuevo pago:"));
                            break;
                        case "Especialidad":
                            doctor.Especialidad = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese la nueva especialidad:"));
                            break;
                        case "Cancelar":
                            break;
                    }

                    AnsiConsole.MarkupLine($"Atributo actualizado con éxito para el Dr. {doctor.Nombre} {doctor.Apellido}");
                    DisplayDoctorsList();
                }

                private static void DeleteDoctor(int doctorID)
                {
                    var doctorToDelete = Doctores.doctores.FirstOrDefault(d => d.ID == doctorID);

                    if (doctorToDelete != null)
                    {
                        Doctores.doctores.Remove(doctorToDelete);
                        AnsiConsole.MarkupLine($"Doctor {doctorToDelete.Nombre} {doctorToDelete.Apellido} eliminado.");
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold red]Doctor no encontrado. Verifique el ID e inténtelo de nuevo.[/]");
                        DisplayDoctorsList();
                    }
                }
       
                public static Doctores SelectDoctor()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Doctores:[/]");
                    var doctorOptions = Doctores.doctores.Select(doctor =>
                    {
                        return $"{doctor.ID}. {doctor.Nombre} {doctor.Apellido}";
                    }).ToArray();

                    var doctorID = AnsiConsole.Prompt(new SelectionPrompt<string>()
                        .Title("Seleccione un doctor:")
                        .PageSize(10)
                        .AddChoices(doctorOptions));

                    var selectedDoctorID = int.Parse(doctorID.Split('.')[0]);

                    var selectedDoctor = Doctores.doctores.FirstOrDefault(d => d.ID == selectedDoctorID);

                    return selectedDoctor;
                }
                           
            }

            public class Doctores : Usuarios
            {
                public double Pago { get; set; }
                public bool PagoStatus{get; set;}
                public string Especialidad { get; set; }

                public Doctores()
                {

                }
                public Doctores(int aID, string aNombre, string aApellido, string aEmai, string aContraseña, double aPago, string aEspecialidad) : base(aID, aNombre, aApellido, aEmai, aContraseña)
                {
                    Pago = aPago;
                    PagoStatus = false;
                    Especialidad = aEspecialidad;
                }

                public static List<Doctores> doctores = new List<Doctores>()
                {
                    new Doctores(1, "Martin", "Pastora", "Mpastora@gmail.com", "Pastora1", 0, "Medicina General"),
                    new Doctores(2, "Laura", "Gonzalez", "lgonzalez@gmail.com", "Gonzalez1", 0, "Pediatría"),
                    new Doctores(3, "Carlos", "Martinez", "cmartinez@gmail.com", "Martinez1", 0, "Cirugía"),
                    new Doctores(4, "Ana", "Lopez", "alopez@gmail.com", "Lopez1", 0, "Dermatología"),
                    new Doctores(5, "Pedro", "Sanchez", "psanchez@gmail.com", "Sanchez1", 0, "Ginecología"),
                    new Doctores(6, "María", "Rodriguez", "mrodriguez@gmail.com", "Rodriguez1", 0, "Cardiología")
                };

                public static void DisplayDoctorsList()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Doctores:[/]");
                    foreach (var doctor in doctores)
                    {
                        AnsiConsole.MarkupLine($"[yellow]{doctor.ID}.[/] [green]{doctor.Nombre} {doctor.Apellido}[/] - [blue]{doctor.Especialidad}[/]");
                    }
                }

                public static void DisplayDoctorAppointments()
                {
                    if (string.IsNullOrEmpty(SessionHandler.loggedInName))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: No hay ningún doctor conectado.[/]");
                        return;
                    }

                    var loggedInDoctor = doctores.FirstOrDefault(d => d.Nombre.Equals(SessionHandler.loggedInName));

                    if (loggedInDoctor == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: No se encontró el doctor conectado.[/]");
                        return;
                    }

                    var doctorAppointments = Usuarios.Data.Appointments.Where(appointment => appointment.DoctorAssignment.Equals($"{loggedInDoctor.Nombre} {loggedInDoctor.Apellido} - {loggedInDoctor.Especialidad}")).ToList();

                    if (doctorAppointments.Any())
                    {
                        AnsiConsole.MarkupLine($"[bold]Lista de citas para el doctor {loggedInDoctor.Nombre} {loggedInDoctor.Apellido}[/]");
                        foreach (var appointment in doctorAppointments)
                        {
                            AnsiConsole.WriteLine($"Nombre: {appointment.Nombre} {appointment.Apellido}");
                            AnsiConsole.WriteLine($"Fecha: {appointment.AppointmentDate}");
                            AnsiConsole.WriteLine($"Hora: {appointment.AppointmentTime}");
                            AnsiConsole.WriteLine($"Mensaje: {appointment.Message}");
                            AnsiConsole.WriteLine($"Estado: {(appointment.AppointmentStatus ? "Activa" : "Inactiva")}");
                            AnsiConsole.WriteLine();
                        }
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold]No hay citas programadas para este doctor.[/]");
                    }
                }
            }


            public class Pacientes : Usuarios
            {

                public Pacientes(int aID, string aNombre, string aApellido, string aEmail, string aContraseña) : base(aID, aNombre, aApellido, aEmail, aContraseña)
                {

                }
                public static List<Pacientes> pacientes = new List<Pacientes>()
                {
                    new Pacientes(1, "Juan", "García", "jgarcia@gmail.com", "Garcia1"),
                    new Pacientes(2, "María", "López", "mlopez@gmail.com", "Lopez1"),
                    new Pacientes(3, "Pedro", "Martínez", "pmartinez@gmail.com", "Martinez1"),
                    new Pacientes(4, "Laura", "Rodríguez", "lrodriguez@gmail.com", "Rodriguez1"),
                    new Pacientes(5, "Carlos", "Hernández", "chernandez@gmail.com", "Hernandez1"),
                    new Pacientes(6, "Ana", "González", "agonzalez@gmail.com", "Gonzalez1"),
                    new Pacientes(7, "David", "Pérez", "dperez@gmail.com", "Perez1"),
                    new Pacientes(8, "Elena", "Díaz", "ediaz@gmail.com", "Diaz1"),
                    new Pacientes(9, "José", "Fernández", "jfernandez@gmail.com", "Fernandez1"),
                    new Pacientes(10, "Sofía", "Vázquez", "svazquez@gmail.com", "Vazquez1")
                };

                public static void DisplayPatientsList()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Pacientes:[/]");
                    foreach (var patient in pacientes)
                    {
                        AnsiConsole.MarkupLine($"[yellow]{patient.ID}.[/] [green]{patient.Nombre} {patient.Apellido}[/] - [blue]{patient.Email}[/]");
                    }
                }

                public static void DisplayPatientAppointments()
                {

                    if (string.IsNullOrEmpty(SessionHandler.loggedInName))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: No hay ningún paciente conectado.[/]");
                        return;
                    }

                    var patientAppointments = Data.Appointments.Where(appointment => appointment.Nombre.Equals(SessionHandler.loggedInName) || appointment.Apellido.Equals(SessionHandler.loggedInName)).ToList();

                    if (patientAppointments.Any())
                    {
                        AnsiConsole.MarkupLine($"[bold]Lista de citas para el paciente {SessionHandler.loggedInName}[/]");
                        foreach (var appointment in patientAppointments)
                        {
                            AnsiConsole.WriteLine($"Fecha: {appointment.AppointmentDate}");
                            AnsiConsole.WriteLine($"Hora: {appointment.AppointmentTime}");
                            AnsiConsole.WriteLine($"Mensaje: {appointment.Message}");
                            AnsiConsole.WriteLine($"Estado: {(appointment.AppointmentStatus ? "Activa" : "Inactiva")}");
                            AnsiConsole.WriteLine();
                        }
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold]No hay citas programadas para este paciente.[/]");
                    }
                }

                public static Pacientes SelectPatient()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Pacientes:[/]");
                    
                    var patientOptions = pacientes.Select(patient =>
                    {
                        return $"{patient.ID}. {patient.Nombre} {patient.Apellido}";
                    }).ToArray();

                    var patientID = AnsiConsole.Prompt(new SelectionPrompt<string>()
                        .Title("Seleccione un paciente:")
                        .PageSize(10)
                        .AddChoices(patientOptions));

                    var selectedPatientID = int.Parse(patientID.Split('.')[0]);

                    var selectedPatient = pacientes.FirstOrDefault(p => p.ID == selectedPatientID);

                    return selectedPatient;
                }

                public static void DisplayDoctorAppointmentsAndPatientHistory()
                {
                    if (string.IsNullOrEmpty(SessionHandler.loggedInName))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: No hay ningún doctor conectado.[/]");
                        return;
                    }

                    var loggedInDoctor = Usuarios.Doctores.doctores.FirstOrDefault(d => d.Nombre.Equals(SessionHandler.loggedInName));

                    if (loggedInDoctor == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: No se encontró el doctor conectado.[/]");
                        return;
                    }

                    var doctorAppointments = Usuarios.Data.Appointments.Where(appointment => appointment.DoctorAssignment.Equals($"{loggedInDoctor.Nombre} {loggedInDoctor.Apellido} - {loggedInDoctor.Especialidad}")).ToList();

                    if (doctorAppointments.Any())
                    {
                        AnsiConsole.MarkupLine($"[bold]Lista de citas para el doctor {loggedInDoctor.Nombre} {loggedInDoctor.Apellido}[/]");
                        foreach (var appointment in doctorAppointments)
                        {
                            AnsiConsole.WriteLine($"Nombre: {appointment.Nombre} {appointment.Apellido}");
                            AnsiConsole.WriteLine($"Fecha: {appointment.AppointmentDate}");
                            AnsiConsole.WriteLine($"Hora: {appointment.AppointmentTime}");
                            AnsiConsole.WriteLine($"Mensaje: {appointment.Message}");
                            AnsiConsole.WriteLine($"Estado: {(appointment.AppointmentStatus ? "Activa" : "Inactiva")}");
                            AnsiConsole.WriteLine();
                        }

                        var selectedAppointment = AnsiConsole.Prompt(
                            new SelectionPrompt<string>()
                                .Title("Seleccione una cita para ver el historial del paciente")
                                .PageSize(10)
                                .AddChoices(doctorAppointments.Select(appointment => $"{appointment.Nombre} {appointment.Apellido}")));

                        var selectedPatientAppointment = doctorAppointments.FirstOrDefault(appointment => $"{appointment.Nombre} {appointment.Apellido}".Equals(selectedAppointment));

                        if (selectedPatientAppointment != null)
                        {
                            var patientRecord = Usuarios.Data.Records.FirstOrDefault(record => record.Nombre.Equals(selectedPatientAppointment.Nombre) && record.Apellido.Equals(selectedPatientAppointment.Apellido));

                            if (patientRecord != null)
                            {
                                AnsiConsole.MarkupLine($"[bold]Historial del paciente {patientRecord.Nombre} {patientRecord.Apellido}[/]");
                                AnsiConsole.WriteLine($"Fecha de la cita: {selectedPatientAppointment.AppointmentDate}");
                                AnsiConsole.WriteLine($"Hora de la cita: {selectedPatientAppointment.AppointmentTime}");
                                AnsiConsole.WriteLine($"Mensaje de la cita: {selectedPatientAppointment.Message}");
                                AnsiConsole.WriteLine($"Estado de la cita: {(selectedPatientAppointment.AppointmentStatus ? "Activa" : "Inactiva")}");
                                AnsiConsole.WriteLine($"Fecha de actualización: {patientRecord.LastUpdated}");
                            }
                            else
                            {
                                AnsiConsole.MarkupLine("[bold red]Error: No se encontró el historial del paciente.[/]");
                            }
                        }
                        else
                        {
                            AnsiConsole.MarkupLine("[bold red]Error: No se seleccionó ninguna cita.[/]");
                        }
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold]No hay citas programadas para este doctor.[/]");
                    }
                }

                public static void DisplayPatientHistoryFromRecords()
                {

                    if (string.IsNullOrEmpty(SessionHandler.loggedInName))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: No hay ningún paciente conectado.[/]");
                        return;
                    }

                    var patientRecords = Data.Records.Where(record => record.Nombre.Equals(SessionHandler.loggedInName) || record.Apellido.Equals(SessionHandler.loggedInName)).ToList();

                    if (patientRecords.Any())
                    {
                        AnsiConsole.MarkupLine($"[bold]Historial del paciente {SessionHandler.loggedInName}[/]");
                        foreach (var record in patientRecords)
                        {
                            AnsiConsole.WriteLine($"Fecha de la cita: {record.AppointmentDate}");
                            AnsiConsole.WriteLine($"Hora de la cita: {record.AppointmentTime}");
                            AnsiConsole.WriteLine($"Mensaje de la cita: {record.Message}");
                            AnsiConsole.WriteLine($"Estado de la cita: {(record.AppointmentStatus ? "Activa" : "Inactiva")}");
                            AnsiConsole.WriteLine($"Fecha de actualización: {record.LastUpdated}");
                            AnsiConsole.WriteLine();
                        }
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold]No hay historial disponible para este paciente.[/]");
                    }
                }
                
            }


            public class Data : Usuarios
            {
                public bool AppointmentStatus { get; set; }
                public DateOnly AppointmentDate { get; set; }
                public TimeSpan AppointmentTime { get; set; }
                public string Message { get; set; }
                public string DoctorAssignment { get; set; }
                public DateTime LastUpdated { get; set; }

                public Data()
                {

                }

 
                public Data(string nombre, string apellido, string aDoctor, DateOnly appointmentDate, TimeSpan appointmentTime, string aMessage, bool appointmentStatus)
                {
                    Nombre = nombre;
                    Apellido = apellido;
                    DoctorAssignment = aDoctor;
                    AppointmentDate = appointmentDate;
                    AppointmentTime = appointmentTime;
                    Message = aMessage;
                    AppointmentStatus = appointmentStatus;
                }

                public static List<Data> Appointments = new List<Data>()
                {
                    new Data("Juan", "García", "Martin" ,new DateOnly(2024, 5, 13), new TimeSpan(10, 0, 0), "Dolor de cabeza", false),
                    new Data("Maria", "Lopez", "Laura" ,new DateOnly(2024, 5, 13), new TimeSpan(10, 0, 0), "Revision", false),
                    new Data("Pedro", "Martínez", "Carlos" ,new DateOnly(2024, 5, 13), new TimeSpan(10, 0, 0), "Visita previa a la cirugia", false),

                };


                public Data(string nombre, string apellido, DateOnly appointmentDate, TimeSpan appointmentTime, string aMessage, bool appointmentStatus, DateTime lastUpdated)
                {
                    Nombre = nombre;
                    Apellido = apellido;
                    AppointmentDate = appointmentDate;
                    AppointmentTime = appointmentTime;
                    Message = aMessage;
                    AppointmentStatus = appointmentStatus;
                    LastUpdated = lastUpdated;
                }

                public static List<Data> Records = new List<Data>()
                {
                    new Data("John", "Doe", new DateOnly(2024, 5, 12), new TimeSpan(14, 30, 0), "Appointment message", true, DateTime.Now),
                    new Data("Jane", "Smith", new DateOnly(2024, 5, 13), new TimeSpan(10, 0, 0), "Another appointment message", false, DateTime.Now)
                };


                public static void DisplayAdminSubMenuCitas()
                {
                    var option = AnsiConsole.Prompt(new SelectionPrompt<Menus.CitasAdministratorSubMenu>()
                        .Title("Seleccione una opción:")
                        .PageSize(5)
                        .AddChoices(
                            Menus.CitasAdministratorSubMenu.AgregarNuevaCita,
                            Menus.CitasAdministratorSubMenu.CancelarCita,
                            Menus.CitasAdministratorSubMenu.Cancelar
                        ));

                    switch (option)
                    {
                        case Menus.CitasAdministratorSubMenu.AgregarNuevaCita:
                            AnsiConsole.Clear();
                            AgregarNuevaCita();
                            Menus.DoctorMenu();
                            break;
                        case Menus.CitasAdministratorSubMenu.CancelarCita:
                            AnsiConsole.Clear();
                            CancelarCita();
                            Menus.DoctorMenu();
                            break;
                        case Menus.CitasAdministratorSubMenu.Cancelar:
                            AnsiConsole.Clear();
                            Menus.AdministradorsMenu();
                            Menus.DoctorMenu();
                            break;
                        default:
                            throw new NotImplementedException($"Opción no implementada: {option}");
                    }
                }

                public static void AgregarNuevaCita()
                {
                    var selectedPatient = Pacientes.SelectPatient();

                    if (selectedPatient == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: Paciente no encontrado. Seleccione un paciente existente.[/]");
                        return;
                    }

                    DisplayDoctorsListWithSpecialties();

                    var selectedDoctor = SelectDoctorWithSpecialty();

                    if (selectedDoctor == null)
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: Doctor no seleccionado.[/]");
                        return;
                    }

                    var appointmentDateStr = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese la fecha de la cita (yyyy-MM-dd):"));
                    var appointmentTimeStr = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese la hora de la cita (HH:mm):"));

                    if (!DateOnly.TryParse(appointmentDateStr, out DateOnly appointmentDate))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: Formato de fecha inválido. Utilice el formato yyyy-MM-dd.[/]");
                        return;
                    }

                    if (!TimeSpan.TryParse(appointmentTimeStr, out TimeSpan appointmentTime))
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: Formato de hora inválido. Utilice el formato HH:mm.[/]");
                        return;
                    }

                    var message = AnsiConsole.Prompt(new TextPrompt<string>("Ingrese un mensaje para la cita (opcional):"));

                    var newAppointment = new Data()
                    {
                        ID = Appointments.Count + 1,
                        Nombre = selectedPatient.Nombre,
                        Apellido = selectedPatient.Apellido,
                        Email = selectedPatient.Email,
                        AppointmentStatus = true,
                        AppointmentDate = appointmentDate,
                        AppointmentTime = appointmentTime,
                        Message = message ?? "", 
                        DoctorAssignment = $"{selectedDoctor.Nombre} {selectedDoctor.Apellido} - {selectedDoctor.Especialidad}"
                    };

                    Appointments.Add(newAppointment);
                    Records.Add(new Data(newAppointment.Nombre, newAppointment.Apellido, newAppointment.AppointmentDate, newAppointment.AppointmentTime, newAppointment.Message, newAppointment.AppointmentStatus, DateTime.Now));

                    AnsiConsole.MarkupLine("[bold green]Nueva cita agregada exitosamente.[/]");
                    DisplayAppointmentsList();
                    DisplayAdminSubMenuCitas();
                }

                private static void DisplayDoctorsListWithSpecialties()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Doctores con Especialidades:[/]");
                    foreach (var doctor in Doctores.doctores)
                    {
                        AnsiConsole.MarkupLine($"[yellow]{doctor.ID}.[/] [green]{doctor.Nombre} {doctor.Apellido}[/] - [blue]{doctor.Especialidad}[/]");
                    }
                }

                private static Doctores SelectDoctorWithSpecialty()
                {
                    var doctorID = AnsiConsole.Prompt(new TextPrompt<int>("Seleccione el ID del doctor para la cita:"));

                    var selectedDoctor = Doctores.doctores.FirstOrDefault(d => d.ID == doctorID);

                    return selectedDoctor;
                }

                public static void CancelarCita()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Citas:[/]");
                    DisplayAppointmentsList();

                    var appointmentID = AnsiConsole.Prompt(new TextPrompt<int>("Ingrese el ID de la cita que desea cancelar:"));

                    var appointmentToCancel = Appointments.FirstOrDefault(a => a.ID == appointmentID);

                    if (appointmentToCancel != null)
                    {

                        Records.Add(new Data(appointmentToCancel.Nombre, appointmentToCancel.Apellido, appointmentToCancel.AppointmentDate, appointmentToCancel.AppointmentTime, appointmentToCancel.Message, appointmentToCancel.AppointmentStatus, DateTime.Now));

                        Appointments.Remove(appointmentToCancel);

                        AnsiConsole.MarkupLine("[bold green]Cita cancelada exitosamente.[/]");
                        if (Appointments.Count != 0)
                        {
                            DisplayAppointmentsList();
                        }
                        else
                        {
                            AnsiConsole.MarkupLine("[bold red]\nNo hay citas\n[/]");
                            AnsiConsole.WriteLine("");
                            DisplayAdminSubMenuCitas();
                        }
                    }
                    else
                    {
                        AnsiConsole.MarkupLine("[bold red]Error: Cita no encontrada. Verifique el ID e inténtelo de nuevo.[/]");
                    }
                }

                private static void DisplayAppointmentsList()
                {
                    AnsiConsole.MarkupLine("[bold cyan]Lista de Citas:[/]");
                    foreach (var appointment in Appointments)
                    {
                        string appointmentTimeString = appointment.AppointmentTime.ToString(@"hh\:mm");
                        AnsiConsole.MarkupLine($"[yellow]{appointment.ID}.[/] [green]{appointment.Nombre} {appointment.Apellido}[/] - [blue]{appointment.AppointmentDate.ToString("yyyy-MM-dd")} {appointmentTimeString}[/] - Doctor: [blue]{appointment.DoctorAssignment}[/] - Mensaje: {appointment.Message ?? "[italic grey]Ninguno[/]"}");
                    }
                }
            } 
    }
}
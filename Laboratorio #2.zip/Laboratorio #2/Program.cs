﻿using System;

namespace MedicalManagementSystem
{
    public class PrincipalClass
    {
        public static void Main(string[] args)
        {
            SessionHandler sessionHandler = new SessionHandler();
              sessionHandler.Initializer();
        }
    }
}
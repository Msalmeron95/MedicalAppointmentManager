using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using Spectre.Console;
using MedicalManagementSystem;
using System.Reflection.Metadata;


namespace MedicalManagementSystem
{
    public class SessionHandler
    {
        public static string? loggedInName;
        public static string? loggedInUserEmail;
        public static int loggedInUserID;

        public SessionHandler()
        {
            
        }

        public void Initializer()
        {
            while (true)
            {
                var choice = AnsiConsole.Prompt(
                    new SelectionPrompt<Menus.LoginMenu>()
                        .Title("Login Menu")
                        .PageSize(3)
                        .AddChoices(Menus.LoginMenu.Login, Menus.LoginMenu.Salir)
                );

                switch (choice)
                {
                    case Menus.LoginMenu.Login:
                        Login();
                        break;
                    case Menus.LoginMenu.Salir:
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            }
        }

        public void Login()
        {
            AnsiConsole.MarkupLine("[bold yellow]Inicio de Sesión[/]");
            var email = AnsiConsole.Ask<string>("Email:");
            var password = AnsiConsole.Prompt(new TextPrompt<string>("Contraseña:").Secret());

            var admin = Usuarios.Administradores.admins.FirstOrDefault(u => u.Email == email && u.Contraseña == password);
            if (admin != null)
            {
                AnsiConsole.Clear();
                AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Admin:{admin.Nombre}![/]");
                loggedInName = admin.Nombre;
                loggedInUserEmail = email; 
                loggedInUserID = admin.ID; 
                Menus.AdministradorsMenu();
                return;
            }

            var doctor = Usuarios.Doctores.doctores.FirstOrDefault(u => u.Email == email && u.Contraseña == password);
            if (doctor != null)
            {
                AnsiConsole.Clear();
                AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Dr. {doctor.Nombre}![/]");
                loggedInName = doctor.Nombre;
                loggedInUserEmail = email; 
                loggedInUserID = doctor.ID;
                Menus.DoctorMenu();
                return;
            }

            var patient = Usuarios.Pacientes.pacientes.FirstOrDefault(u => u.Email == email && u.Contraseña == password);
            if (patient != null)
            {
                AnsiConsole.Clear();
                AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, {patient.Nombre}![/]");
                loggedInName = patient.Nombre;
                loggedInUserEmail = email; 
                loggedInUserID = patient.ID;
                Menus.PacientesMenu();
                return;
            }

            AnsiConsole.MarkupLine("[bold red]¡Email o contraseña incorrectos![/]");
            AnsiConsole.Clear();

        }
        
        public string GetLoggedInUserEmail()
        {
            return loggedInUserEmail;
        }
    }
}
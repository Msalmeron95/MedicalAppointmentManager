using System;
using Spectre.Console;

namespace MedicalManagementSystem
{
    public class Menus
    {

        public enum LoginMenu
        {
            Login,
            Salir
        }
    
        public enum AdministradorMenu
        {
            GestionarPagos,
            Gestiondedoctores,
            VerCitas,
            VerPacientes,
            VerDoctores,
            Salir
        }

        public enum CitasAdministratorSubMenu
        {
            AgregarNuevaCita,
            CancelarCita,
            Cancelar
            
        }

        public enum DoctorsMenu
        {
            VerPacientes,
            VerHistorialPaciente,
            CancelarCita,
            Salir
        }

        public enum PacienteMenu
        {
            VerDoctoresDisponibles,
            AgendarCita,
            VerCitas,
            VerHistorial,
            Salir
        }

        public static void AdministradorsMenu()
        {
            var selectedOption = AnsiConsole.Prompt(
                new SelectionPrompt<AdministradorMenu>()
                    .Title("Seleccione una opción:")
                    .PageSize(6)
                    .MoreChoicesText("Más opciones")
                    .AddChoices(AdministradorMenu.GestionarPagos,
                                AdministradorMenu.Gestiondedoctores,
                                AdministradorMenu.VerCitas,
                                AdministradorMenu.VerPacientes,
                                AdministradorMenu.VerDoctores,
                                AdministradorMenu.Salir));

            switch (selectedOption)
            {
                case AdministradorMenu.GestionarPagos:
                    AnsiConsole.Clear();
                    AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Admin:{SessionHandler.loggedInName}![/]");
                    AnsiConsole.WriteLine("Gestionar pagos seleccionado");
                    Usuarios.Administradores.ManageDoctorPayments();
                    AnsiConsole.Clear();

                    break;
                case AdministradorMenu.Gestiondedoctores:
                    AnsiConsole.Clear();
                    AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Admin:{SessionHandler.loggedInName}![/]");
                    AnsiConsole.WriteLine("Gestion de doctores seleccionado");
                    Usuarios.Administradores.ManageDoctors();

                    break;
                case AdministradorMenu.VerCitas:
                    AnsiConsole.Clear();
                    AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Admin:{SessionHandler.loggedInName}![/]");
                    AnsiConsole.WriteLine("Ver citas seleccionado");
                    Usuarios.Data.DisplayAdminSubMenuCitas();

                    break;
                case AdministradorMenu.VerPacientes:
                    AnsiConsole.Clear();
                    AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Admin:{SessionHandler.loggedInName}![/]");
                    AnsiConsole.WriteLine("Ver pacientes seleccionado");
                    Usuarios.Pacientes.DisplayPatientsList();
                    AnsiConsole.WriteLine("");
                    AdministradorsMenu();

                    break;
                case AdministradorMenu.VerDoctores:
                    AnsiConsole.Clear();
                    AnsiConsole.MarkupLine($"[bold green]¡Bienvenido, Admin:{SessionHandler.loggedInName}![/]");
                    AnsiConsole.WriteLine("Ver doctores seleccionado");
                    Usuarios.Doctores.DisplayDoctorsList();
                    AnsiConsole.WriteLine("");
                    AdministradorsMenu();

                    break;
                case AdministradorMenu.Salir:
                    AnsiConsole.MarkupLine($"[bold red]Saliendo...![/]");
                    AnsiConsole.Clear();
                    break;
                default:
                    AnsiConsole.WriteLine("Opción no válida");
                    break;
            }
        }

        public static void DoctorMenu()
        {
            var selectedOption = AnsiConsole.Prompt(
                new SelectionPrompt<DoctorsMenu>()
                    .Title("Seleccione una opción:")
                    .PageSize(5)
                    .MoreChoicesText("Más opciones")
                    .AddChoices(DoctorsMenu.VerPacientes,
                                DoctorsMenu.VerHistorialPaciente,
                                DoctorsMenu.CancelarCita,
                                DoctorsMenu.Salir));

            switch (selectedOption)
            {

                case DoctorsMenu.VerPacientes:
                    AnsiConsole.Clear();
                    AnsiConsole.WriteLine("Ver pacientes seleccionado");
                    Usuarios.Doctores.DisplayDoctorAppointments();
                    DoctorMenu();
                    break;
                case DoctorsMenu.VerHistorialPaciente:
                    AnsiConsole.Clear();
                    AnsiConsole.WriteLine("Ver historial de paciente seleccionado");
                    Usuarios.Pacientes.DisplayDoctorAppointmentsAndPatientHistory();
                    DoctorMenu();
                    break;
                case DoctorsMenu.CancelarCita:
                    AnsiConsole.WriteLine("Cancelar cita seleccionado");
                    Usuarios.Data.CancelarCita();
                    DoctorMenu();
                    break;
                case DoctorsMenu.Salir:
                    AnsiConsole.WriteLine("Saliendo...");
                    break;
                default:
                    AnsiConsole.WriteLine("Opción no válida");
                    break;
            }
        }

        public static void PacientesMenu()
        {
            var selectedOption = AnsiConsole.Prompt(
                new SelectionPrompt<PacienteMenu>()
                    .Title("Seleccione una opción:")
                    .PageSize(5)
                    .MoreChoicesText("Más opciones")
                    .AddChoices(PacienteMenu.VerDoctoresDisponibles,
                                PacienteMenu.AgendarCita,
                                PacienteMenu.VerCitas,
                                PacienteMenu.VerHistorial,
                                PacienteMenu.Salir));

            switch (selectedOption)
            {
                case PacienteMenu.VerDoctoresDisponibles:
                    AnsiConsole.WriteLine("Ver doctores disponibles seleccionado");
                    Usuarios.Doctores.DisplayDoctorsList();
                    PacientesMenu();
                    break;
                case PacienteMenu.AgendarCita:
                    AnsiConsole.WriteLine("Agendar cita seleccionado");
                    Usuarios.Data.AgregarNuevaCita();
                    PacientesMenu();
                    break;
                case PacienteMenu.VerCitas:
                    AnsiConsole.WriteLine("Ver citas seleccionado");
                    Usuarios.Pacientes.DisplayPatientAppointments();
                    PacientesMenu();
                    break;
                case PacienteMenu.VerHistorial:
                    AnsiConsole.WriteLine("Ver historial seleccionado");
                    Usuarios.Pacientes.DisplayDoctorAppointmentsAndPatientHistory();
                    PacientesMenu();
                    break;
                case PacienteMenu.Salir:
                    AnsiConsole.WriteLine("Saliendo...");
                    break;
                default:
                    AnsiConsole.WriteLine("Opción no válida");
                    break;
            }
        }

    }
}